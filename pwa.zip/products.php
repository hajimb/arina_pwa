<?php $pagename = 'profile' ?>
<?php include('includes/top.php'); ?>
<div id="wrapper">
<?php include('includes/header.php'); ?>

<div class="content-page">
    <div class="content">
        <!-- Start Content-->
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <h4 class="page-title">Products List</h4>
                </div>
            </div> 
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="card-box">
                        <div class="member-card-alt">
                            <h4 class="mb-1 mt-0">Ring - Fashion Rings</h4>
                            <h5 class="mb-2 mt-0">Title will come here</h5>
                            <div class="avatar-xxl member-thumb mb-2 float-left">
                                <div id="carouselExample" class="carousel slide" data-ride="carousel">
                                    <ol class="carousel-indicators">
                                        <li data-target="#carouselExample" data-slide-to="0" class="active"></li>
                                        <li data-target="#carouselExample" data-slide-to="1"></li>
                                        <li data-target="#carouselExample" data-slide-to="2"></li>
                                    </ol>
                                    <div class="carousel-inner" role="listbox">
                                        <div class="carousel-item active">
                                            <a href='assets/images/design/FROF2711S.jpg' data-lightbox='#title_1'><img id='title_1' alt='FROF2711S' src='assets/images/design/FROF2711S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-4.jpg" alt="First slide" /> -->
                                        </div>
                                        <div class="carousel-item">
                                            <a href='assets/images/design/EAHT7738S.jpg' data-lightbox='#title_1'><img id='title_1' alt='EAHT7738S' src='assets/images/design/EAHT7738S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-5.jpg" alt="Second slide" /> -->
                                        </div>
                                        <div class="carousel-item">
                                            <a href='assets/images/design/PEOH6282S.jpg' data-lightbox='#title_1'><img id='title_1' alt='PEOH6282S' src='assets/images/design/PEOH6282S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-6.jpg" alt="Third slide" /> -->
                                        </div>
                                    </div>
                                </div>    
                                <!-- <i class="mdi mdi-star-circle member-star text-success" title="verified user"></i> -->
                            </div>

                            <div class="member-card-alt-info">
                                <h6 class="mb-1 mt-1">Style No.: EDFJ434FD</h6>
                                <h6 class="mb-1 mt-2">Diamond Wg: 2.1 K</h6>
                                <h6 class="mb-1 mt-2">Gold Wg:</h6>
                                <ul class="list-unstyled">
                                    <li>9 kt : 10 gm</li>
                                    <li>10 kt : 12 gm</li>
                                    <li>14 kt : 15 gm</li>
                                    <li>18 kt : 19 gm</li>
                                    <li>925 S : 22 gm</li>
                                </ul>
                            </div>
                            <div class="row">
                                <div class="col-4">
                                    <div class="mt-2">
                                        <h4 class="mb-0">200</h4>
                                        <p class="mb-0 text-muted">Ordered</p>
                                    </div>
                                </div>
                                <div class="col-8 text-right">
                                    <button type="button" class="btn btn-success btn-sm mt-2 waves-effect waves-light"> Order </button>
                                    <button type="button" class="btn btn-warning btn-sm mt-2 waves-effect waves-light"> Enquire </button>
                                    <button type="button" class="btn btn-danger btn-sm mt-2 waves-effect waves-light"> Reject </button>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="card-box">
                        <div class="member-card-alt">
                            <h4 class="mb-1 mt-0">Ring - Fashion Rings</h4>
                            <h5 class="mb-2 mt-0">Title will come here</h5>
                            <div class="avatar-xxl member-thumb mb-2 float-left">
                                <div id="carouselExample" class="carousel slide" data-ride="carousel">
                                    <ol class="carousel-indicators">
                                        <li data-target="#carouselExample" data-slide-to="0" class="active"></li>
                                        <li data-target="#carouselExample" data-slide-to="1"></li>
                                        <li data-target="#carouselExample" data-slide-to="2"></li>
                                    </ol>
                                    <div class="carousel-inner" role="listbox">
                                        <div class="carousel-item active">
                                            <a href='assets/images/design/FROF2711S.jpg' data-lightbox='#title_2'><img id='title_2' alt='FROF2711S' src='assets/images/design/FROF2711S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-4.jpg" alt="First slide" /> -->
                                        </div>
                                        <div class="carousel-item">
                                            <a href='assets/images/design/EAHT7738S.jpg' data-lightbox='#title_2'><img id='title_2' alt='EAHT7738S' src='assets/images/design/EAHT7738S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-5.jpg" alt="Second slide" /> -->
                                        </div>
                                        <div class="carousel-item">
                                            <a href='assets/images/design/PEOH6282S.jpg' data-lightbox='#title_2'><img id='title_2' alt='PEOH6282S' src='assets/images/design/PEOH6282S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-6.jpg" alt="Third slide" /> -->
                                        </div>
                                    </div>
                                </div> 
                                <!-- <i class="mdi mdi-star-circle member-star text-success" title="verified user"></i> -->
                            </div>

                            <div class="member-card-alt-info">
                                <h6 class="mb-1 mt-1">Style No.: EDFJ434FD</h6>
                                <h6 class="mb-1 mt-2">Diamond Wg: 2.1 K</h6>
                                <h6 class="mb-1 mt-2">Gold Wg:</h6>
                                <ul class="list-unstyled">
                                    <li>9 kt : 10 gm</li>
                                    <li>10 kt : 12 gm</li>
                                    <li>14 kt : 15 gm</li>
                                    <li>18 kt : 19 gm</li>
                                    <li>925 S : 22 gm</li>
                                </ul>
                            </div>
                            <div class="row">
                                <div class="col-4">
                                    <div class="mt-2">
                                        <h4 class="mb-0">200</h4>
                                        <p class="mb-0 text-muted">Ordered</p>
                                    </div>
                                </div>
                                <div class="col-8 text-right">
                                    <button type="button" class="btn btn-success btn-sm mt-2 waves-effect waves-light"> Order </button>
                                    <button type="button" class="btn btn-warning btn-sm mt-2 waves-effect waves-light"> Enquire </button>
                                    <button type="button" class="btn btn-danger btn-sm mt-2 waves-effect waves-light"> Reject </button>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="card-box">
                        <div class="member-card-alt">
                            <h4 class="mb-1 mt-0">Ring - Fashion Rings</h4>
                            <h5 class="mb-2 mt-0">Title will come here</h5>
                            <div class="avatar-xxl member-thumb mb-2 float-left">
                                <div id="carouselExample" class="carousel slide" data-ride="carousel">
                                    <ol class="carousel-indicators">
                                        <li data-target="#carouselExample" data-slide-to="0" class="active"></li>
                                        <li data-target="#carouselExample" data-slide-to="1"></li>
                                        <li data-target="#carouselExample" data-slide-to="2"></li>
                                    </ol>
                                    <div class="carousel-inner" role="listbox">
                                        <div class="carousel-item active">
                                            <a href='assets/images/design/FROF2711S.jpg' data-lightbox='#title_3'><img id='title_3' alt='FROF2711S' src='assets/images/design/FROF2711S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-4.jpg" alt="First slide" /> -->
                                        </div>
                                        <div class="carousel-item">
                                            <a href='assets/images/design/EAHT7738S.jpg' data-lightbox='#title_3'><img id='title_3' alt='EAHT7738S' src='assets/images/design/EAHT7738S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-5.jpg" alt="Second slide" /> -->
                                        </div>
                                        <div class="carousel-item">
                                            <a href='assets/images/design/PEOH6282S.jpg' data-lightbox='#title_3'><img id='title_3' alt='PEOH6282S' src='assets/images/design/PEOH6282S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-6.jpg" alt="Third slide" /> -->
                                        </div>
                                    </div>
                                </div> 
                                <!-- <i class="mdi mdi-star-circle member-star text-success" title="verified user"></i> -->
                            </div>

                            <div class="member-card-alt-info">
                                <h6 class="mb-1 mt-1">Style No.: EDFJ434FD</h6>
                                <h6 class="mb-1 mt-2">Diamond Wg: 2.1 K</h6>
                                <h6 class="mb-1 mt-2">Gold Wg:</h6>
                                <ul class="list-unstyled">
                                    <li>9 kt : 10 gm</li>
                                    <li>10 kt : 12 gm</li>
                                    <li>14 kt : 15 gm</li>
                                    <li>18 kt : 19 gm</li>
                                    <li>925 S : 22 gm</li>
                                </ul>
                            </div>
                            <div class="row">
                                <div class="col-4">
                                    <div class="mt-2">
                                        <h4 class="mb-0">200</h4>
                                        <p class="mb-0 text-muted">Ordered</p>
                                    </div>
                                </div>
                                <div class="col-8 text-right">
                                    <button type="button" class="btn btn-success btn-sm mt-2 waves-effect waves-light"> Order </button>
                                    <button type="button" class="btn btn-warning btn-sm mt-2 waves-effect waves-light"> Enquire </button>
                                    <button type="button" class="btn btn-danger btn-sm mt-2 waves-effect waves-light"> Reject </button>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="card-box">
                        <div class="member-card-alt">
                            <h4 class="mb-1 mt-0">Ring - Fashion Rings</h4>
                            <h5 class="mb-2 mt-0">Title will come here</h5>
                            <div class="avatar-xxl member-thumb mb-2 float-left">
                                <div id="carouselExample" class="carousel slide" data-ride="carousel">
                                    <ol class="carousel-indicators">
                                        <li data-target="#carouselExample" data-slide-to="0" class="active"></li>
                                        <li data-target="#carouselExample" data-slide-to="1"></li>
                                        <li data-target="#carouselExample" data-slide-to="2"></li>
                                    </ol>
                                    <div class="carousel-inner" role="listbox">
                                        <div class="carousel-item active">
                                            <a href='assets/images/design/FROF2711S.jpg' data-lightbox='#title_4'><img id='title_4' alt='FROF2711S' src='assets/images/design/FROF2711S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-4.jpg" alt="First slide" /> -->
                                        </div>
                                        <div class="carousel-item">
                                            <a href='assets/images/design/EAHT7738S.jpg' data-lightbox='#title_4'><img id='title_4' alt='EAHT7738S' src='assets/images/design/EAHT7738S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-5.jpg" alt="Second slide" /> -->
                                        </div>
                                        <div class="carousel-item">
                                            <a href='assets/images/design/PEOH6282S.jpg' data-lightbox='#title_4'><img id='title_4' alt='PEOH6282S' src='assets/images/design/PEOH6282S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-6.jpg" alt="Third slide" /> -->
                                        </div>
                                    </div>
                                </div> 
                                <!-- <i class="mdi mdi-star-circle member-star text-success" title="verified user"></i> -->
                            </div>

                            <div class="member-card-alt-info">
                                <h6 class="mb-1 mt-1">Style No.: EDFJ434FD</h6>
                                <h6 class="mb-1 mt-2">Diamond Wg: 2.1 K</h6>
                                <h6 class="mb-1 mt-2">Gold Wg:</h6>
                                <ul class="list-unstyled">
                                    <li>9 kt : 10 gm</li>
                                    <li>10 kt : 12 gm</li>
                                    <li>14 kt : 15 gm</li>
                                    <li>18 kt : 19 gm</li>
                                    <li>925 S : 22 gm</li>
                                </ul>
                            </div>
                            <div class="row">
                                <div class="col-4">
                                    <div class="mt-2">
                                        <h4 class="mb-0">200</h4>
                                        <p class="mb-0 text-muted">Ordered</p>
                                    </div>
                                </div>
                                <div class="col-8 text-right">
                                    <button type="button" class="btn btn-success btn-sm mt-2 waves-effect waves-light"> Order </button>
                                    <button type="button" class="btn btn-warning btn-sm mt-2 waves-effect waves-light"> Enquire </button>
                                    <button type="button" class="btn btn-danger btn-sm mt-2 waves-effect waves-light"> Reject </button>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="card-box">
                        <div class="member-card-alt">
                            <h4 class="mb-1 mt-0">Ring - Fashion Rings</h4>
                            <h5 class="mb-2 mt-0">Title will come here</h5>
                            <div class="avatar-xxl member-thumb mb-2 float-left">
                                <div id="carouselExample" class="carousel slide" data-ride="carousel">
                                    <ol class="carousel-indicators">
                                        <li data-target="#carouselExample" data-slide-to="0" class="active"></li>
                                        <li data-target="#carouselExample" data-slide-to="1"></li>
                                        <li data-target="#carouselExample" data-slide-to="2"></li>
                                    </ol>
                                    <div class="carousel-inner" role="listbox">
                                        <div class="carousel-item active">
                                            <a href='assets/images/design/FROF2711S.jpg' data-lightbox='#title_5'><img id='title_5' alt='FROF2711S' src='assets/images/design/FROF2711S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-4.jpg" alt="First slide" /> -->
                                        </div>
                                        <div class="carousel-item">
                                            <a href='assets/images/design/EAHT7738S.jpg' data-lightbox='#title_5'><img id='title_5' alt='EAHT7738S' src='assets/images/design/EAHT7738S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-5.jpg" alt="Second slide" /> -->
                                        </div>
                                        <div class="carousel-item">
                                            <a href='assets/images/design/PEOH6282S.jpg' data-lightbox='#title_5'><img id='title_5' alt='PEOH6282S' src='assets/images/design/PEOH6282S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-6.jpg" alt="Third slide" /> -->
                                        </div>
                                    </div>
                                </div> 
                                <!-- <i class="mdi mdi-star-circle member-star text-success" title="verified user"></i> -->
                            </div>

                            <div class="member-card-alt-info">
                                <h6 class="mb-1 mt-1">Style No.: EDFJ434FD</h6>
                                <h6 class="mb-1 mt-2">Diamond Wg: 2.1 K</h6>
                                <h6 class="mb-1 mt-2">Gold Wg:</h6>
                                <ul class="list-unstyled">
                                    <li>9 kt : 10 gm</li>
                                    <li>10 kt : 12 gm</li>
                                    <li>14 kt : 15 gm</li>
                                    <li>18 kt : 19 gm</li>
                                    <li>925 S : 22 gm</li>
                                </ul>
                            </div>
                            <div class="row">
                                <div class="col-4">
                                    <div class="mt-2">
                                        <h4 class="mb-0">200</h4>
                                        <p class="mb-0 text-muted">Ordered</p>
                                    </div>
                                </div>
                                <div class="col-8 text-right">
                                    <button type="button" class="btn btn-success btn-sm mt-2 waves-effect waves-light"> Order </button>
                                    <button type="button" class="btn btn-warning btn-sm mt-2 waves-effect waves-light"> Enquire </button>
                                    <button type="button" class="btn btn-danger btn-sm mt-2 waves-effect waves-light"> Reject </button>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="card-box">
                        <div class="member-card-alt">
                            <h4 class="mb-1 mt-0">Ring - Fashion Rings</h4>
                            <h5 class="mb-2 mt-0">Title will come here</h5>
                            <div class="avatar-xxl member-thumb mb-2 float-left">
                                <div id="carouselExample" class="carousel slide" data-ride="carousel">
                                    <ol class="carousel-indicators">
                                        <li data-target="#carouselExample" data-slide-to="0" class="active"></li>
                                        <li data-target="#carouselExample" data-slide-to="1"></li>
                                        <li data-target="#carouselExample" data-slide-to="2"></li>
                                    </ol>
                                    <div class="carousel-inner" role="listbox">
                                        <div class="carousel-item active">
                                            <a href='assets/images/design/FROF2711S.jpg' data-lightbox='#title_6'><img id='title_6' alt='FROF2711S' src='assets/images/design/FROF2711S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-4.jpg" alt="First slide" /> -->
                                        </div>
                                        <div class="carousel-item">
                                            <a href='assets/images/design/EAHT7738S.jpg' data-lightbox='#title_6'><img id='title_6' alt='EAHT7738S' src='assets/images/design/EAHT7738S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-5.jpg" alt="Second slide" /> -->
                                        </div>
                                        <div class="carousel-item">
                                            <a href='assets/images/design/PEOH6282S.jpg' data-lightbox='#title_6'><img id='title_6' alt='PEOH6282S' src='assets/images/design/PEOH6282S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-6.jpg" alt="Third slide" /> -->
                                        </div>
                                    </div>
                                </div> 
                                <!-- <i class="mdi mdi-star-circle member-star text-success" title="verified user"></i> -->
                            </div>

                            <div class="member-card-alt-info">
                                <h6 class="mb-1 mt-1">Style No.: EDFJ434FD</h6>
                                <h6 class="mb-1 mt-2">Diamond Wg: 2.1 K</h6>
                                <h6 class="mb-1 mt-2">Gold Wg:</h6>
                                <ul class="list-unstyled">
                                    <li>9 kt : 10 gm</li>
                                    <li>10 kt : 12 gm</li>
                                    <li>14 kt : 15 gm</li>
                                    <li>18 kt : 19 gm</li>
                                    <li>925 S : 22 gm</li>
                                </ul>
                            </div>
                            <div class="row">
                                <div class="col-4">
                                    <div class="mt-2">
                                        <h4 class="mb-0">200</h4>
                                        <p class="mb-0 text-muted">Ordered</p>
                                    </div>
                                </div>
                                <div class="col-8 text-right">
                                    <button type="button" class="btn btn-success btn-sm mt-2 waves-effect waves-light"> Order </button>
                                    <button type="button" class="btn btn-warning btn-sm mt-2 waves-effect waves-light"> Enquire </button>
                                    <button type="button" class="btn btn-danger btn-sm mt-2 waves-effect waves-light"> Reject </button>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="card-box">
                        <div class="member-card-alt">
                            <h4 class="mb-1 mt-0">Ring - Fashion Rings</h4>
                            <h5 class="mb-2 mt-0">Title will come here</h5>
                            <div class="avatar-xxl member-thumb mb-2 float-left">
                                <div id="carouselExample" class="carousel slide" data-ride="carousel">
                                    <ol class="carousel-indicators">
                                        <li data-target="#carouselExample" data-slide-to="0" class="active"></li>
                                        <li data-target="#carouselExample" data-slide-to="1"></li>
                                        <li data-target="#carouselExample" data-slide-to="2"></li>
                                    </ol>
                                    <div class="carousel-inner" role="listbox">
                                        <div class="carousel-item active">
                                            <a href='assets/images/design/FROF2711S.jpg' data-lightbox='#title_7'><img id='title_7' alt='FROF2711S' src='assets/images/design/FROF2711S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-4.jpg" alt="First slide" /> -->
                                        </div>
                                        <div class="carousel-item">
                                            <a href='assets/images/design/EAHT7738S.jpg' data-lightbox='#title_7'><img id='title_7' alt='EAHT7738S' src='assets/images/design/EAHT7738S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-5.jpg" alt="Second slide" /> -->
                                        </div>
                                        <div class="carousel-item">
                                            <a href='assets/images/design/PEOH6282S.jpg' data-lightbox='#title_7'><img id='title_7' alt='PEOH6282S' src='assets/images/design/PEOH6282S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-6.jpg" alt="Third slide" /> -->
                                        </div>
                                    </div>
                                </div> 
                                <!-- <i class="mdi mdi-star-circle member-star text-success" title="verified user"></i> -->
                            </div>

                            <div class="member-card-alt-info">
                                <h6 class="mb-1 mt-1">Style No.: EDFJ434FD</h6>
                                <h6 class="mb-1 mt-2">Diamond Wg: 2.1 K</h6>
                                <h6 class="mb-1 mt-2">Gold Wg:</h6>
                                <ul class="list-unstyled">
                                    <li>9 kt : 10 gm</li>
                                    <li>10 kt : 12 gm</li>
                                    <li>14 kt : 15 gm</li>
                                    <li>18 kt : 19 gm</li>
                                    <li>925 S : 22 gm</li>
                                </ul>
                            </div>
                            <div class="row">
                                <div class="col-4">
                                    <div class="mt-2">
                                        <h4 class="mb-0">200</h4>
                                        <p class="mb-0 text-muted">Ordered</p>
                                    </div>
                                </div>
                                <div class="col-8 text-right">
                                    <button type="button" class="btn btn-success btn-sm mt-2 waves-effect waves-light"> Order </button>
                                    <button type="button" class="btn btn-warning btn-sm mt-2 waves-effect waves-light"> Enquire </button>
                                    <button type="button" class="btn btn-danger btn-sm mt-2 waves-effect waves-light"> Reject </button>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="card-box">
                        <div class="member-card-alt">
                            <h4 class="mb-1 mt-0">Ring - Fashion Rings</h4>
                            <h5 class="mb-2 mt-0">Title will come here</h5>
                            <div class="avatar-xxl member-thumb mb-2 float-left">
                                <div id="carouselExample" class="carousel slide" data-ride="carousel">
                                    <ol class="carousel-indicators">
                                        <li data-target="#carouselExample" data-slide-to="0" class="active"></li>
                                        <li data-target="#carouselExample" data-slide-to="1"></li>
                                        <li data-target="#carouselExample" data-slide-to="2"></li>
                                    </ol>
                                    <div class="carousel-inner" role="listbox">
                                        <div class="carousel-item active">
                                            <a href='assets/images/design/FROF2711S.jpg' data-lightbox='#title_8'><img id='title_8' alt='FROF2711S' src='assets/images/design/FROF2711S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-4.jpg" alt="First slide" /> -->
                                        </div>
                                        <div class="carousel-item">
                                            <a href='assets/images/design/EAHT7738S.jpg' data-lightbox='#title_8'><img id='title_8' alt='EAHT7738S' src='assets/images/design/EAHT7738S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-5.jpg" alt="Second slide" /> -->
                                        </div>
                                        <div class="carousel-item">
                                            <a href='assets/images/design/PEOH6282S.jpg' data-lightbox='#title_8'><img id='title_8' alt='PEOH6282S' src='assets/images/design/PEOH6282S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-6.jpg" alt="Third slide" /> -->
                                        </div>
                                    </div>
                                </div> 
                                <!-- <i class="mdi mdi-star-circle member-star text-success" title="verified user"></i> -->
                            </div>

                            <div class="member-card-alt-info">
                                <h6 class="mb-1 mt-1">Style No.: EDFJ434FD</h6>
                                <h6 class="mb-1 mt-2">Diamond Wg: 2.1 K</h6>
                                <h6 class="mb-1 mt-2">Gold Wg:</h6>
                                <ul class="list-unstyled">
                                    <li>9 kt : 10 gm</li>
                                    <li>10 kt : 12 gm</li>
                                    <li>14 kt : 15 gm</li>
                                    <li>18 kt : 19 gm</li>
                                    <li>925 S : 22 gm</li>
                                </ul>
                            </div>
                            <div class="row">
                                <div class="col-4">
                                    <div class="mt-2">
                                        <h4 class="mb-0">200</h4>
                                        <p class="mb-0 text-muted">Ordered</p>
                                    </div>
                                </div>
                                <div class="col-8 text-right">
                                    <button type="button" class="btn btn-success btn-sm mt-2 waves-effect waves-light"> Order </button>
                                    <button type="button" class="btn btn-warning btn-sm mt-2 waves-effect waves-light"> Enquire </button>
                                    <button type="button" class="btn btn-danger btn-sm mt-2 waves-effect waves-light"> Reject </button>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="card-box">
                        <div class="member-card-alt">
                            <h4 class="mb-1 mt-0">Ring - Fashion Rings</h4>
                            <h5 class="mb-2 mt-0">Title will come here</h5>
                            <div class="avatar-xxl member-thumb mb-2 float-left">
                                <div id="carouselExample" class="carousel slide" data-ride="carousel">
                                    <ol class="carousel-indicators">
                                        <li data-target="#carouselExample" data-slide-to="0" class="active"></li>
                                        <li data-target="#carouselExample" data-slide-to="1"></li>
                                        <li data-target="#carouselExample" data-slide-to="2"></li>
                                    </ol>
                                    <div class="carousel-inner" role="listbox">
                                        <div class="carousel-item active">
                                            <a href='assets/images/design/FROF2711S.jpg' data-lightbox='#title_9'><img id='title_9' alt='FROF2711S' src='assets/images/design/FROF2711S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-4.jpg" alt="First slide" /> -->
                                        </div>
                                        <div class="carousel-item">
                                            <a href='assets/images/design/EAHT7738S.jpg' data-lightbox='#title_9'><img id='title_9' alt='EAHT7738S' src='assets/images/design/EAHT7738S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-5.jpg" alt="Second slide" /> -->
                                        </div>
                                        <div class="carousel-item">
                                            <a href='assets/images/design/PEOH6282S.jpg' data-lightbox='#title_9'><img id='title_9' alt='PEOH6282S' src='assets/images/design/PEOH6282S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-6.jpg" alt="Third slide" /> -->
                                        </div>
                                    </div>
                                </div> 
                                <!-- <i class="mdi mdi-star-circle member-star text-success" title="verified user"></i> -->
                            </div>

                            <div class="member-card-alt-info">
                                <h6 class="mb-1 mt-1">Style No.: EDFJ434FD</h6>
                                <h6 class="mb-1 mt-2">Diamond Wg: 2.1 K</h6>
                                <h6 class="mb-1 mt-2">Gold Wg:</h6>
                                <ul class="list-unstyled">
                                    <li>9 kt : 10 gm</li>
                                    <li>10 kt : 12 gm</li>
                                    <li>14 kt : 15 gm</li>
                                    <li>18 kt : 19 gm</li>
                                    <li>925 S : 22 gm</li>
                                </ul>
                            </div>
                            <div class="row">
                                <div class="col-4">
                                    <div class="mt-2">
                                        <h4 class="mb-0">200</h4>
                                        <p class="mb-0 text-muted">Ordered</p>
                                    </div>
                                </div>
                                <div class="col-8 text-right">
                                    <button type="button" class="btn btn-success btn-sm mt-2 waves-effect waves-light"> Order </button>
                                    <button type="button" class="btn btn-warning btn-sm mt-2 waves-effect waves-light"> Enquire </button>
                                    <button type="button" class="btn btn-danger btn-sm mt-2 waves-effect waves-light"> Reject </button>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="card-box">
                        <div class="member-card-alt">
                            <h4 class="mb-1 mt-0">Ring - Fashion Rings</h4>
                            <h5 class="mb-2 mt-0">Title will come here</h5>
                            <div class="avatar-xxl member-thumb mb-2 float-left">
                                <div id="carouselExample" class="carousel slide" data-ride="carousel">
                                    <ol class="carousel-indicators">
                                        <li data-target="#carouselExample" data-slide-to="0" class="active"></li>
                                        <li data-target="#carouselExample" data-slide-to="1"></li>
                                        <li data-target="#carouselExample" data-slide-to="2"></li>
                                    </ol>
                                    <div class="carousel-inner" role="listbox">
                                        <div class="carousel-item active">
                                            <a href='assets/images/design/FROF2711S.jpg' data-lightbox='#title_10'><img id='title_10' alt='FROF2711S' src='assets/images/design/FROF2711S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-4.jpg" alt="First slide" /> -->
                                        </div>
                                        <div class="carousel-item">
                                            <a href='assets/images/design/EAHT7738S.jpg' data-lightbox='#title_10'><img id='title_10' alt='EAHT7738S' src='assets/images/design/EAHT7738S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-5.jpg" alt="Second slide" /> -->
                                        </div>
                                        <div class="carousel-item">
                                            <a href='assets/images/design/PEOH6282S.jpg' data-lightbox='#title_10'><img id='title_10' alt='PEOH6282S' src='assets/images/design/PEOH6282S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-6.jpg" alt="Third slide" /> -->
                                        </div>
                                    </div>
                                </div> 
                                <!-- <i class="mdi mdi-star-circle member-star text-success" title="verified user"></i> -->
                            </div>

                            <div class="member-card-alt-info">
                                <h6 class="mb-1 mt-1">Style No.: EDFJ434FD</h6>
                                <h6 class="mb-1 mt-2">Diamond Wg: 2.1 K</h6>
                                <h6 class="mb-1 mt-2">Gold Wg:</h6>
                                <ul class="list-unstyled">
                                    <li>9 kt : 10 gm</li>
                                    <li>10 kt : 12 gm</li>
                                    <li>14 kt : 15 gm</li>
                                    <li>18 kt : 19 gm</li>
                                    <li>925 S : 22 gm</li>
                                </ul>
                            </div>
                            <div class="row">
                                <div class="col-4">
                                    <div class="mt-2">
                                        <h4 class="mb-0">200</h4>
                                        <p class="mb-0 text-muted">Ordered</p>
                                    </div>
                                </div>
                                <div class="col-8 text-right">
                                    <button type="button" class="btn btn-success btn-sm mt-2 waves-effect waves-light"> Order </button>
                                    <button type="button" class="btn btn-warning btn-sm mt-2 waves-effect waves-light"> Enquire </button>
                                    <button type="button" class="btn btn-danger btn-sm mt-2 waves-effect waves-light"> Reject </button>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="card-box">
                        <div class="member-card-alt">
                            <h4 class="mb-1 mt-0">Ring - Fashion Rings</h4>
                            <h5 class="mb-2 mt-0">Title will come here</h5>
                            <div class="avatar-xxl member-thumb mb-2 float-left">
                                <div id="carouselExample" class="carousel slide" data-ride="carousel">
                                    <ol class="carousel-indicators">
                                        <li data-target="#carouselExample" data-slide-to="0" class="active"></li>
                                        <li data-target="#carouselExample" data-slide-to="1"></li>
                                        <li data-target="#carouselExample" data-slide-to="2"></li>
                                    </ol>
                                    <div class="carousel-inner" role="listbox">
                                        <div class="carousel-item active">
                                            <a href='assets/images/design/FROF2711S.jpg' data-lightbox='#title_11'><img id='title_11' alt='FROF2711S' src='assets/images/design/FROF2711S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-4.jpg" alt="First slide" /> -->
                                        </div>
                                        <div class="carousel-item">
                                            <a href='assets/images/design/EAHT7738S.jpg' data-lightbox='#title_11'><img id='title_11' alt='EAHT7738S' src='assets/images/design/EAHT7738S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-5.jpg" alt="Second slide" /> -->
                                        </div>
                                        <div class="carousel-item">
                                            <a href='assets/images/design/PEOH6282S.jpg' data-lightbox='#title_11'><img id='title_11' alt='PEOH6282S' src='assets/images/design/PEOH6282S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-6.jpg" alt="Third slide" /> -->
                                        </div>
                                    </div>
                                </div> 
                                <!-- <i class="mdi mdi-star-circle member-star text-success" title="verified user"></i> -->
                            </div>

                            <div class="member-card-alt-info">
                                <h6 class="mb-1 mt-1">Style No.: EDFJ434FD</h6>
                                <h6 class="mb-1 mt-2">Diamond Wg: 2.1 K</h6>
                                <h6 class="mb-1 mt-2">Gold Wg:</h6>
                                <ul class="list-unstyled">
                                    <li>9 kt : 10 gm</li>
                                    <li>10 kt : 12 gm</li>
                                    <li>14 kt : 15 gm</li>
                                    <li>18 kt : 19 gm</li>
                                    <li>925 S : 22 gm</li>
                                </ul>
                            </div>
                            <div class="row">
                                <div class="col-4">
                                    <div class="mt-2">
                                        <h4 class="mb-0">200</h4>
                                        <p class="mb-0 text-muted">Ordered</p>
                                    </div>
                                </div>
                                <div class="col-8 text-right">
                                    <button type="button" class="btn btn-success btn-sm mt-2 waves-effect waves-light"> Order </button>
                                    <button type="button" class="btn btn-warning btn-sm mt-2 waves-effect waves-light"> Enquire </button>
                                    <button type="button" class="btn btn-danger btn-sm mt-2 waves-effect waves-light"> Reject </button>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="card-box">
                        <div class="member-card-alt">
                            <h4 class="mb-1 mt-0">Ring - Fashion Rings</h4>
                            <h5 class="mb-2 mt-0">Title will come here</h5>
                            <div class="avatar-xxl member-thumb mb-2 float-left">
                                <div id="carouselExample" class="carousel slide" data-ride="carousel">
                                    <ol class="carousel-indicators">
                                        <li data-target="#carouselExample" data-slide-to="0" class="active"></li>
                                        <li data-target="#carouselExample" data-slide-to="1"></li>
                                        <li data-target="#carouselExample" data-slide-to="2"></li>
                                    </ol>
                                    <div class="carousel-inner" role="listbox">
                                        <div class="carousel-item active">
                                            <a href='assets/images/design/FROF2711S.jpg' data-lightbox='#title_12'><img id='title_12' alt='FROF2711S' src='assets/images/design/FROF2711S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-4.jpg" alt="First slide" /> -->
                                        </div>
                                        <div class="carousel-item">
                                            <a href='assets/images/design/EAHT7738S.jpg' data-lightbox='#title_12'><img id='title_12' alt='EAHT7738S' src='assets/images/design/EAHT7738S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-5.jpg" alt="Second slide" /> -->
                                        </div>
                                        <div class="carousel-item">
                                            <a href='assets/images/design/PEOH6282S.jpg' data-lightbox='#title_12'><img id='title_12' alt='PEOH6282S' src='assets/images/design/PEOH6282S.jpg' class='img-thumbnail'></a>    
                                            <!-- <img class="d-block img-fluid" src="assets/images/small/img-6.jpg" alt="Third slide" /> -->
                                        </div>
                                    </div>
                                </div> 
                                <!-- <i class="mdi mdi-star-circle member-star text-success" title="verified user"></i> -->
                            </div>

                            <div class="member-card-alt-info">
                                <h6 class="mb-1 mt-1">Style No.: EDFJ434FD</h6>
                                <h6 class="mb-1 mt-2">Diamond Wg: 2.1 K</h6>
                                <h6 class="mb-1 mt-2">Gold Wg:</h6>
                                <ul class="list-unstyled">
                                    <li>9 kt : 10 gm</li>
                                    <li>10 kt : 12 gm</li>
                                    <li>14 kt : 15 gm</li>
                                    <li>18 kt : 19 gm</li>
                                    <li>925 S : 22 gm</li>
                                </ul>
                            </div>
                            <div class="row">
                                <div class="col-4">
                                    <div class="mt-2">
                                        <h4 class="mb-0">200</h4>
                                        <p class="mb-0 text-muted">Ordered</p>
                                    </div>
                                </div>
                                <div class="col-8 text-right">
                                    <button type="button" class="btn btn-success btn-sm mt-2 waves-effect waves-light"> Order </button>
                                    <button type="button" class="btn btn-warning btn-sm mt-2 waves-effect waves-light"> Enquire </button>
                                    <button type="button" class="btn btn-danger btn-sm mt-2 waves-effect waves-light"> Reject </button>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
            <!-- end row -->
        </div> <!-- end container-fluid -->

    </div> <!-- end content -->

    

    <!-- Footer Start -->
    <footer class="footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    2022 © Arina Jewellery
                </div>
            </div>
        </div>
    </footer>
    <!-- end Footer -->

</div>

<!-- ============================================================== -->
<!-- End Page content -->
<!-- ============================================================== -->

</div>
<style>
      .carousel-indicators li {
    background-color:  #000 !important;
    width: 10px !important;
  }
  .carousel-indicators{
    bottom: -15px !important;

  }
  </style>

<?php include('includes/script.php'); ?>
</body>
</html>
<script>
var dlat = 19.153903855786677;
var dlng = 72.83898421740493;
</script>