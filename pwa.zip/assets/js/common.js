
function toaster( msg, header, type){
    $.toast({ heading: header, text: msg, hideAfter: 3e3, position: "top-right", icon: type, stack:1 });
}