var map, marker ;

function initMap() {
  const myLatLng = { lat: dlat, lng: dlng };
  map = new google.maps.Map(document.getElementById("map"), {
    zoom: 15,
    center: myLatLng,
  });
  marker = new google.maps.Marker({
    position: myLatLng,
    map,
    title: "Company Location ",
    draggable:false,
  });

  // Create the initial InfoWindow.
  let infoWindow = new google.maps.InfoWindow({
    content: "Click the map to get Lat/Lng!",
    position: myLatLng,
  });
 // infoWindow.open(map);
   // Configure the click listener.
  marker.addListener("dragend", (mapsMouseEvent) => {
    // Close the current InfoWindow.
    //alert('fdfdfd');
    // infoWindow.close();
    // Create a new InfoWindow.
    setLocation(mapsMouseEvent.latLng.lat, mapsMouseEvent.latLng.lng);
    // infoWindow = new google.maps.InfoWindow({
    //   position: mapsMouseEvent.latLng,
    // });
    // infoWindow.setContent(
    //   JSON.stringify(mapsMouseEvent.latLng.toJSON(), null, 2)
    // );
    // infoWindow.open(map);
  });
  const geocoder = new google.maps.Geocoder();
}

function setLocation(lat, lng){
    $("#latitude").val(lat);  
    $("#longitude").val(lng); 
}
  