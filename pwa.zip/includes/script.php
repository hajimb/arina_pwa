
    <!-- Vendor js -->
    <script src="assets/js/vendor.min.js"></script>

    <!-- App js -->
    <script src="assets/js/app.js"></script>
    
    <!-- LightBox js -->
    <script src="assets/libs/lightbox2/lightbox.min.js"></script>
    <script src="assets/js/jquery.serializeToJSON.js"></script>
    <script src="assets/libs/jquery-toast/jquery.toast.min.js"></script>
    <script src="assets/js/common.js"></script>

<?php if($pagename == "dashboard") {?>
    <!-- Sparkline charts -->
    <script src="assets/libs/jquery-sparkline/jquery.sparkline.min.js"></script>

    <script src="assets/js/pages/profile.init.js"></script>

    <!-- Responsive Table js -->
    <script src="assets/libs/rwd-table/rwd-table.min.js"></script>


<?php }else if($pagename == "login"){ ?>
    <script src="script.js"></script>
<?php }else if($pagename == "profile"){ ?>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCunoKdw5Q4F_XWdetqy7JhmrZWpinb4zQ&callback=initMap&libraries=&v=weekly" defer></script>
    
    <!-- LightBox js -->
    <script src="assets/js/profile.js"></script>
<?php } ?>
<script>
    var base_url = "http://localhost:8080/arina_app/pwa/";
    var api_url = "http://localhost:8080/arina_app/admin/";
</script>