<?php $pagename = 'profile' ?>
<?php include('includes/top.php'); ?>
<style>
    #map {
        height: 100%;
        border: 1px solid #cecece;
    }
</style>
<div id="wrapper">

<?php include('includes/header.php'); ?>


<!-- ============================================================== -->
<!-- Start Page Content here -->
<!-- ============================================================== -->

<div class="content-page">
    <div class="content">
        
        <!-- Start Content-->
        <div class="container-fluid">
            
            <div class="row">
                <div class="col-md-12">
                    <div class="profile-bg-picture" style="background-image:url('assets/images/bg-profile.jpg')">
                        <span class="picture-bg-overlay"></span><!-- overlay -->
                    </div>
                    <!-- meta -->
                    <div class="profile-user-box">
                        <div class="row">
                            <div class="col-md-6">
                                <span class="float-left mr-3"><img src="assets/images/companies/airbnb.png" alt="" class="avatar-xl rounded-circle"></span>
                                <div class="media-body">
                                    <h4 class="mt-1 mb-1 font-18 ellipsis">Company Name</h4>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="text-right">
                                    <!-- <button type="button" class="btn btn-success waves-effect waves-light">
                                        <i class="mdi mdi-account-settings-variant mr-1"></i> Edit Profile
                                    </button> -->
                                </div>
                            </div>
                            <div class="col-md-12 mt-3">
                                <hr>
                            </div>
                            <div class="col-md-6 mt-3">
                                <h4 class="header-title mt-0 mb-4">Company Address</h4>
                                <div class="panel-body">
                                    <p class="text-muted font-13">
                                        UNIT NO. 174/A, SDF VI, SEEPZ-SEZ, <br/>
                                        Andheri - Kurla Rd, Mumbai- 400096 <br/>
                                        Maharashtra India
                                    </p>
                                    <hr>
                                    <h4 class="header-title mt-0 mb-4">Company Details</h4>
                                    <p class="text-muted font-13"><strong>Email ID :</strong> <span class="ml-3">company@email.com</span></p>
                                    <p class="text-muted font-13"><strong>Phone No :</strong> <span class="ml-3">022 - 25856256</span></p>
                                    <p class="text-muted font-13"><strong>Website :</strong> <span class="ml-3">http://www.arinajewellery.com/</span></p>
                                    <p class="text-muted font-13"><strong>Tax ID no :</strong> <span class="ml-3">DDFJ233FSFD234FDSF</span></p>
                                    <hr>
                                    <h4 class="header-title mt-0 mb-4">Contact Person Details</h4>
                                    <p class="text-muted font-13"><strong>Full Name :</strong> <span class="ml-3">Johnathan Deo</span></p>
                                    <p class="text-muted font-13"><strong>Mobile :</strong><span class="ml-3">(+12) 123 1234 567</span></p>
                                    <p class="text-muted font-13"><strong>Email :</strong> <span class="ml-3">coderthemes@gmail.com</span></p>
                                </div>
                            </div>
                            <div class="col-md-6 mb-2" style="min-height:200px;">
                                <div id="map"></div>
                            </div>
                        </div>
                    </div>
                    <!--/ meta -->
                </div>
            </div>
            <!-- end row -->
            
        </div> <!-- end container-fluid -->

    </div> <!-- end content -->

    

    <!-- Footer Start -->
    <footer class="footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    2022 © Arina Jewellery
                </div>
            </div>
        </div>
    </footer>
    <!-- end Footer -->

</div>

<!-- ============================================================== -->
<!-- End Page content -->
<!-- ============================================================== -->

</div>


<?php include('includes/script.php'); ?>
</body>
</html>
<script>
var dlat = 19.153903855786677;
var dlng = 72.83898421740493;
</script>