This is page 1, and it is ...
<?php
sleep(1);
?>
SLOW!
<br><br>
<a href="/">Back to homepage</a>
