let installEvent = null;
let installButton = document.getElementById("install");
let dismissButton = document.getElementById("dismiss");

startPwa();

function startPwa(firstStart) {
	localStorage["pwa-enabled"] = true;

	if(firstStart) {
		location.reload();
	}

	window.addEventListener("load", () => {
		navigator.serviceWorker.register("/service-worker.js")
		.then(registration => {
			console.log("Service Worker is registered", registration);
			// enableButton.parentNode.remove();
		})
		.catch(err => {
			console.error("Registration failed:", err);
		});
	});

	window.addEventListener("beforeinstallprompt", (e) => {
		e.preventDefault();
		console.log("Ready to install...");
		installEvent = e;
		document.getElementById("topnav").style.display = "initial";
	});

	//setTimeout(cacheLinks, 500);

	function cacheLinks() {
		caches.open("arina_cache").then(function(cache) {
			let linksFound = [];
			document.querySelectorAll("a").forEach(function(a) {
				linksFound.push(a.href);
			});

			cache.addAll(linksFound);
		});
	}

	if(installButton) {
		installButton.addEventListener("click", function() {
			installEvent.prompt();
		});
	}
	dismissButton.addEventListener("click", function() {
		document.getElementById("topnav").style.display = "none";
	});
}
